** Project Description**


Integration Flow:

   1. AG notifies market of event via Market Ping Service (with appropriate callback info)
   2.  Ping Service routes to appropriate topic handler and delegates AG callback to topic handler service (e.g. myAudi, FoD, etc)
   
Flow of Events:

   1. AG notifies an event via calling MIL-InboundEvent Service.
   2. Ping Receiver Service authenticates caller with Authorization Server.
   3. Ping Receiver Service validates message and checks whether the ping type and contents are correct.
   4. Ping Receiver Service then writes message to the Kafka topic.
   5. Ping Receiver Service also writes appropriate Transaction logs, App logs, System logs and error logs.
   6. Ping Receiver Service returns 200 OK as a success acknowledgement to AG.
   7. Once AG receives 200 OK, then it sends next message to Ping Receiver Service.
   8. If Ping Receiver Service sends status other than 200 then AG keeps re-sending same message at specific interval until AG receives 200 status.