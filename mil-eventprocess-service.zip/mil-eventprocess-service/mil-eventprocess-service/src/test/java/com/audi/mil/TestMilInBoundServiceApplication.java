//package com.audi.mil;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class TestMilInBoundServiceApplication {
//
//	private MilInBoundServiceApplication milInBoundServiceApplication;
//
//	@SuppressWarnings("static-access")
//	@Test
//	public void TestMain() {
//		milInBoundServiceApplication = new MilInBoundServiceApplication();
//		milInBoundServiceApplication.main(new String[] {});
//
//	}
//}
