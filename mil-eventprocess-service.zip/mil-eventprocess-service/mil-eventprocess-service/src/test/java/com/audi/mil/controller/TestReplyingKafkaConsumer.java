//package com.audi.mil.controller;
//
//import static org.junit.Assert.assertNotNull;
//
//import org.json.JSONException;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.runners.MockitoJUnitRunner;
//
//import com.audi.mil.consumer.ReplyingKafkaConsumer;
//
//@RunWith(MockitoJUnitRunner.class)
//public class TestReplyingKafkaConsumer {
//	
//private ReplyingKafkaConsumer replyingKafkaConsumer;
//	
//@Test	
//public void testListen() throws JSONException {
//	replyingKafkaConsumer = new ReplyingKafkaConsumer();
//	String request ="{\"ping\":6,\"AUDIID\":\"W123003931\",\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\",\"country\": \"CA\"}]}";
//    String response = replyingKafkaConsumer.listen(request);
//	assertNotNull(response);
//	
//}
//	
//}
