//package com.audi.mil.controller;
//
//import static org.junit.Assert.assertNotNull;
//import static org.mockito.Mockito.when;
//
//import org.apache.kafka.clients.consumer.ConsumerRecord;
//import org.apache.kafka.clients.consumer.MockConsumer;
//import org.apache.kafka.clients.consumer.OffsetResetStrategy;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.Matchers;
//import org.mockito.Mock;
//import org.mockito.runners.MockitoJUnitRunner;
//import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
//import org.springframework.kafka.requestreply.RequestReplyFuture;
//
//import com.audi.mil.exception.MilInBoundServiceException;
//import com.audi.mil.validation.MilInBoundServiceValidation;
//
//@RunWith(MockitoJUnitRunner.class)
//public class TestMilInBoundServiceController {
//
//	private MilInBoundServiceController milInBoundServiceController;
//
//	MockConsumer<String, String> consumer;
//
//	@Mock
//	ReplyingKafkaTemplate<String, String, String> kafkaTemplate;
//
//	String request = null;
//	String response = null;
//
//	@Before
//	public void setUp() {
//		milInBoundServiceController = new MilInBoundServiceController();
//		request = "{\"ping\":6,\"audiid\":\"W123003931\",\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\",\"country\": \"CA\"}]}";
//		response = "{\"acknowledgement\": \"Message acknowledged for PingType:6\",\"ping\":6,\"audiid\":\"W123003931\",\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\",\"country\": \"CA\"}]}";
//		milInBoundServiceController.requestTopic = "testTopic";
//		milInBoundServiceController.requestReplyTopic = "testReplyTopic";
//		consumer = new MockConsumer<String, String>(OffsetResetStrategy.EARLIEST);
//		milInBoundServiceController.kafkaTemplate = kafkaTemplate;
//		
//	}
//
//	@Test
//	public void testPingService() throws InterruptedException {
//		RequestReplyFuture<String, String, String> sendAndReceive = new RequestReplyFuture<String, String, String>();
//		ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<String, String>(milInBoundServiceController.requestTopic,
//				0, 0L, null, response);
//		sendAndReceive.set(consumerRecord);
//		when(kafkaTemplate.sendAndReceive(Matchers.any())).thenReturn(sendAndReceive);
//		String response = milInBoundServiceController.pingService(request);
//		assertNotNull(response);
//
//	}
//
//	@Test(expected = MilInBoundServiceException.class)
//	public void testPingServiceNullPingNullAUDIID() throws InterruptedException {
//		String request = "{\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\"}]}";
//		milInBoundServiceController.pingService(request);
//	}
//}
