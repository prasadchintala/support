package com.audi.mil.consumer;

import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.kafka.requestreply.RequestReplyFuture;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;

@Component
public class ReplyingKafkaConsumer {
	private static Logger log = LogManager.getLogger(ReplyingKafkaConsumer.class);

	@Autowired
	ReplyingKafkaTemplate<String, String, String> kafkaTemplate;

	@Value("${kafka.topic.request-topic}")
	String requestTopic;

	@Value("${kafka.topic.requestreply-topic}")
	String requestReplyTopic;

	
	
	@KafkaListener(topics = "${kafka.topic.listener-topic}")
	//@SendTo
	public String listen(String request) throws InterruptedException {
		log.info("Listener: {} PayLoad: {}", requestTopic, request);
		ProducerRecord<String, String> record = new ProducerRecord<>(requestTopic, request);
		log.info("Transaction log create producer record at : {} ", requestTopic);
		record.headers().add(new RecordHeader(KafkaHeaders.REPLY_TOPIC, requestReplyTopic.getBytes()));
		RequestReplyFuture<String, String, String> sendAndReceive = kafkaTemplate.sendAndReceive(record);
		ConsumerRecord<String, String> consumerRecord;
		String objectresponse = null;
		try {
			consumerRecord = sendAndReceive.get();
			objectresponse = consumerRecord.value();
			log.info("Transaction log fetching consumer response as : {} ", consumerRecord.value());
		} catch (InterruptedException e) {
			log.error("Application log Exception occured consumer response reading : {} ", e);
			throw e;
		} catch(ExecutionException ex) {
			log.error("Application log Exception occured consumer response reading : {} ", ex);
		}
		return objectresponse;
		}

}