package com.audi.mil.constants;

public class MILInBoundServiceConstants {
	
	public static final String PING = "ping";
	public static final String AUDI_ID = "audiid";
	public static final String AUDI_ID_CAPS = "AUDIID";

	private MILInBoundServiceConstants() {

	}

}
