package com.audi.mil.exception;

public class MilInBoundServiceException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MilInBoundServiceException(String message) {
		super(message);
	}

}
