
package com.audi.mil.validation;

import com.audi.mil.exception.MilInBoundServiceException;

public class MilInBoundServiceValidation {

	
	public void validatePing(int ping) {
		if(ping<80 || ping >90) {
			throw new MilInBoundServiceException("Ping not in the confined range..It should be should 80 to 90");
		}
		
	}

}