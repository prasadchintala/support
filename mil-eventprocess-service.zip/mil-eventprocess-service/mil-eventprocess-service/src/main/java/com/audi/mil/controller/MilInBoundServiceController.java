//package com.audi.mil.controller;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.MediaType;
//import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.audi.mil.listeners.EventProcessorListener;
//
//@RestController
//@RequestMapping(value = "MIL")
//public class MilInBoundServiceController {
//	private static final Logger logger = LogManager.getLogger(MilInBoundServiceController.class);
//
//	@Autowired
//	ReplyingKafkaTemplate<String, String, String> kafkaTemplate;
//	
////	@Autowired
////	EventProcessorListener eventProcessorListener;
//
//	@Value("${kafka.topic.request-topic}")
//	String requestTopic;
//
//	@Value("${kafka.topic.requestreply-topic}")
//	String requestReplyTopic;
//
//	String acsAPIResponse;
//	
// 
//	@ResponseBody
//	@PostMapping(value = "/milibeventreceiver", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
//	public String pingService(@RequestBody final String request) throws InterruptedException {
//		logger.info("Transaction log recieved request as : {}", request);
//		//String response = eventProcessorListener.getEvent(request);
////		logger.info("Transaction log fetching consumer response as : {} ", response.toString());
////		return response.toString();
//	}
//	
//	}
