package com.audi.mil.exception;

public class MilDataDistributorServiceException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MilDataDistributorServiceException(String message) {
		super(message);
	}

}
