package com.audi.mil.controller;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import com.audi.mil.consumer.MilDataDistributorListener;
import com.audi.mil.service.MarketConsumersService;

@RunWith(MockitoJUnitRunner.class)
public class TestMilDataDistributorListener {

	private MilDataDistributorListener mildataDistributorListener;
	@Mock
	MarketConsumersService marketConsumersService;

	@Test
	public void testListen() throws JSONException {
		marketConsumersService = Mockito.mock(MarketConsumersService.class);
		mildataDistributorListener = new MilDataDistributorListener();
		mildataDistributorListener.setMarketConsumersService(marketConsumersService);
		String request = "{\"ping\":89,\"AUDIID\":\"W123003931\",\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\",\"country\": \"CA\"}]}";
		mildataDistributorListener.getEvent(request);

	}

}
