package com.audi.mil.service;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@RunWith(MockitoJUnitRunner.class)
public class TestMarketConsumerService {
	
	private MarketConsumersService marketConsumersService;
	
	@Mock
	RestTemplate restTemplate;

	
	@Test
	public void testPushToMarketConsumersService() throws JSONException {
		marketConsumersService = new MarketConsumersService();
		String request = "{\"ping\":89,\"AUDIID\":\"W123003931\",\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\",\"country\": \"CA\"}]}";
		restTemplate = Mockito.mock(RestTemplate.class);
		marketConsumersService.restTemplate = restTemplate;
		
		   ResponseEntity<String> myEntity = new ResponseEntity<String>("SUCCESS",HttpStatus.OK);
	        Mockito.when(restTemplate.exchange(
	            Matchers.anyString(),
	            Matchers.any(HttpMethod.class),
	            Matchers.<HttpEntity<?>> any(),
	            Matchers.<Class<String>> any())
	        ).thenReturn(myEntity);

		marketConsumersService.pushToMarketConsumersService(request);;
	}



}
