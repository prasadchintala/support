package com.audi.mil.event.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


@Service
public class EventService {
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	Environment env;
	
	public String getEventService(String event) {
		
		String uri = UriComponentsBuilder.fromHttpUrl(env.getProperty("event.url"))
				.build().encode().toString();
		ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.POST,
				new HttpEntity<Object>(event,new HttpHeaders()), String.class);
		return response.getBody();
	}
	

}
