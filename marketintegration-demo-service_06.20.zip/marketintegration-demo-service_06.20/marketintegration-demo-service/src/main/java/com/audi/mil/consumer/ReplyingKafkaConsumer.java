package com.audi.mil.consumer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;


@Component
public class ReplyingKafkaConsumer {
private static Logger log = LogManager.getLogger(ReplyingKafkaConsumer.class);
	 
	 @KafkaListener(topics = "${kafka.topic.request-topic}")
	 @SendTo
	  public String listen(String request) {
		 JSONObject jsonObject = new JSONObject(request);
		 
		 String acknowledgement = "Message acknowledged for PingType:"+jsonObject.getInt("ping");
		 jsonObject.put("acknowledgement", acknowledgement);
		 log.info("Transaction log consumer acknowledgement msg : {}",jsonObject.toString());
		 return jsonObject.toString();
	  }
	 
}