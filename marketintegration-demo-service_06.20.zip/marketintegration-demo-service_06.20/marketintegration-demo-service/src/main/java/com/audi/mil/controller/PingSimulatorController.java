package com.audi.mil.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.audi.mil.exception.DemoException;

@RestController
@RequestMapping(value = "MIL")
public class PingSimulatorController {

	@Autowired
	RestTemplate restTemplate;
	
	@Value("${ping.receiver.url}")
	String pingReceiverUrl;

	
	private static final Logger logger = LogManager.getLogger(PingSimulatorController.class);

	@ResponseBody
	@PostMapping(value = "/pingsimulator", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpStatus pingSimulatorService(@RequestBody final String request) {
		logger.info("Transaction log in the pingSimulatorService service recieved request as : {}", request);
		JSONObject jsonObject = new JSONObject(request);
		if (jsonObject.isNull("ping")) {
			throw new DemoException("ping is empty");
		}
		int ping = jsonObject.getInt("ping");
		String pingReceiverRequest = setPingReceiverRequest(ping);
		ResponseEntity<String> responseEntity = invokePingReciver(pingReceiverRequest);
		return responseEntity.getStatusCode();
	}

	private ResponseEntity<String> invokePingReciver(String pingReceiverRequest) {
		HttpHeaders headers  = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> requestEntity = new HttpEntity<>(pingReceiverRequest, headers);
		 return restTemplate.exchange(pingReceiverUrl,HttpMethod.POST, requestEntity, String.class);
		
	}

	private String setPingReceiverRequest(int ping) {
		if (ping == 84) {
			return "{\"ping\":84,\"eventDescription\":\"Customer_Created\",\"keyList\":[{\"key\":\"userId\",\"value\":\"de_10070402129512684499\"}],\"json_object\":[{\"integrationInfos\":[{\"systemId\":\"7368968643943927083\",\"integrationId\":\"W117341392\",\"statusInSystem\":\"ACTIVE\",\"lastUpdateInSystem\":\"2019-06-12T08:58:12.104Z\"}],\"legalEntities\":[\"de_10298206035422733073\",\"de_2671997547190545746\"],\"user\":{\"sub\":\"W117341392\",\"iss\":\"int.retailservices.audi.de\",\"legalEntityId\":\"de_10298206035422733073\"},\"businessTransaction\":{\"identifier\":\"myAudi-Profile\",\"id\":\"1466548272\",\"transactionId\":\"1466548272\",\"purpose\":[\"contract\"]}}],\"audiid\":\"de_10070402129512684499\"}";
		} else if (ping == 85) {
			return "{\"ping\":85,\"eventDescription\":\"Customer_Updated\",\"keyList\":[{\"key\":\"userId\",\"value\":\"de_595756279301012228\"}],\"json_object\":[{\"integrationInfos\":[{\"systemId\":\"7368968643943927083\",\"integrationId\":\"W863188740\",\"statusInSystem\":\"ACTIVE\",\"lastUpdateInSystem\":\"2019-06-18T15:41:15.110Z\"},{\"systemId\":\"MBB\",\"integrationId\":\"TGZ2Kg2tt6RhJSWSZt4GFZ5nQTI\",\"statusInSystem\":\"ACTIVE\",\"lastUpdateInSystem\":\"2019-06-18T15:41:15.110Z\"}],\"action\":\"updatePersonCluster\",\"clusterIds\":[\"8b87ede2-c5ad-4035-92f8-4b9039deccae\"],\"legalEntities\":[\"1000\",\"de_2671997547190545746\"],\"user\":{\"sub\":\"W483841613\",\"iss\":\"int.retailservices.audi.de\",\"legalEntityId\":\"1000\"}}],\"audiid\":\"de_595756279301012228\"}";
		} else if (ping == 86) {
			return "{\"ping\":86,\"eventDescription\":\"Customer_Locked\",\"keyList\":[{\"key\":\"userId\",\"value\":\"de_11958539512127068363\"}],\"json_object\":[{\"integrationInfos\":[{\"systemId\":\"7368968643943927083\",\"integrationId\":\"e.g.webssoid\",\"statusInSystem\":\"ACTIVE\",\"lastUpdateInSystem\":\"2018-10-01T00:00:00Z\"}],\"legalEntities\":[\"de_2671997547190545746\"],\"user\":{\"sub\":\"awsi-salesrep@v11.co\",\"iss\":\"int.retailservices.audi.de\",\"legalEntityId\":\"de_2671997547190545746\"}}],\"audiid\":\"de_11958539512127068363\"}";
		} else if (ping == 87) {
			return "{\"ping\":87,\"eventDescription\":\"Customer_Unlocked\",\"keyList\":[{\"key\":\"userId\",\"value\":\"de_14000455977567158632\"}],\"json_object\":[{\"integrationInfos\":[{\"systemId\":\"7368968643943927083\",\"integrationId\":\"e.g.webssoid\",\"statusInSystem\":\"ACTIVE\",\"lastUpdateInSystem\":\"2018-10-01T00:00:00Z\"}],\"legalEntities\":[\"de_2671997547190545746\"],\"user\":{\"sub\":\"awsi-salesrep@v11.co\",\"iss\":\"int.retailservices.audi.de\",\"legalEntityId\":\"de_2671997547190545746\"}}],\"audiid\":\"de_14000455977567158632\"}";
		} else if (ping == 88) {
			return "{\"ping\":88,\"eventDescription\":\"Customer_Deleted\",\"keyList\":[{\"key\":\"userId\",\"value\":\"de_2748682396874654399\"}],\"json_object\":[{\"integrationInfos\":[],\"legalEntities\":[\"de_2671997547190545746\"],\"user\":{\"sub\":\"awsi-salesrep@v11.co\",\"iss\":\"int.retailservices.audi.de\",\"legalEntityId\":\"de_2671997547190545746\"}}],\"audiid\":\"de_2748682396874654399\"}";
		} else if (ping == 89) {
			return "{\"ping\":89,\"eventDescription\":\"Customer_Consent_Granted\",\"keyList\":[{\"key\":\"userId\",\"value\":\"de_10070402129512684499\"}],\"json_object\":[{\"integrationInfos\":[{\"systemId\":\"7368968643943927083\",\"integrationId\":\"W117341392\",\"statusInSystem\":\"ACTIVE\",\"lastUpdateInSystem\":\"2019-06-12T08:58:12.104Z\"}],\"legalEntities\":[\"de_10298206035422733073\",\"de_2671997547190545746\"],\"user\":{\"sub\":\"W117341392\",\"iss\":\"int.retailservices.audi.de\",\"legalEntityId\":\"de_10298206035422733073\"},\"consents\":[{\"identifier\":\"DEU_myAudi_Consenttext_Umfrage\",\"id\":\"de_5757618043833186582\",\"transactionId\":\"130772588\",\"purpose\":\"customer-survey\",\"channels\":[\"email\",\"email\"],\"legalEntityIds\":[\"de_15438289844979051342\"]}]}],\"audiid\":\"de_10070402129512684499\"}";
		} else if (ping == 90) {
			return "{\"ping\":90,\"eventDescription\":\"Customer_Consent_Revoked\",\"keyList\":[{\"key\":\"userId\",\"value\":\"de_9643879768336179314\"}],\"json_object\":[{\"integrationInfos\":[{\"systemId\":\"7368968643943927083\",\"integrationId\":\"W995813443\",\"statusInSystem\":\"ACTIVE\",\"lastUpdateInSystem\":\"2019-06-05T13:51:12.691Z\"},{\"systemId\":\"MBB\",\"integrationId\":\"SCYrdNz6SiAPXtNdzu7MWvI3swS\",\"statusInSystem\":\"ACTIVE\",\"lastUpdateInSystem\":\"2019-06-05T13:51:12.691Z\"}],\"clusterIds\":[\"d842fa08-516c-49f4-951d-d78c1043ca4d\",\"0d9751c7-d114-4c44-9ce6-8d0f110db457\",\"bf9aca51-0416-4f5b-a962-bf6e2daf09e3\",\"02256202-b30b-47d2-83bf-75468ff0bbdb\",\"31e97d94-3a2b-4f61-bd3b-7bb32e99ab62\",\"501501f1-3666-49a7-b475-f54cfb7836a2\",\"1cd59338-4b42-4f56-adc8-8de11363b248\",\"98b695be-ad2a-4a77-b7ba-5ad19560df0a\",\"235ac3e7-3ad0-464a-9d1f-daeb4687a6c3\",\"c64a1640-9e2e-4575-b30d-2f3e3716c1ea\",\"8a3a830b-4cfb-4162-9b2b-5d25696a87dd\",\"d0134404-10b8-40c0-a106-cfe0c6cd26e6\"],\"legalEntities\":[\"de_10298206035422733073\",\"de_15438289844979051342\"],\"user\":{\"sub\":\"W995813443\",\"iss\":\"int.retailservices.audi.de\",\"legalEntityId\":\"de_10298206035422733073\"},\"consents\":[]}],\"audiid\":\"de_9643879768336179314\"}";
		} else {
			throw new DemoException("Ping Not found");
		}

	}

}
