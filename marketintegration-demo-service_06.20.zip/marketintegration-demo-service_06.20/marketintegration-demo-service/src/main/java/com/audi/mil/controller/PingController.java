package com.audi.mil.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.kafka.requestreply.RequestReplyFuture;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.audi.mil.exception.DemoException;

@RestController
@RequestMapping(value = "MIL")

public class PingController {
	public static final String JSON_OBJECT = "json_object";
	private static final Logger logger = LogManager.getLogger(PingController.class);
	
	@Autowired
	ReplyingKafkaTemplate<String, String, String> kafkaTemplate;

	@Value("${kafka.topic.request-topic}")
	String requestTopic;

	@Value("${kafka.topic.requestreply-topic}")
	String requestReplyTopic;
	
	String lastAPIResp;
	
	String acsAPIResponse;

	@ResponseBody
	@PostMapping(value = "/pingreceiver", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String pingService(@RequestBody final String request){
		logger.info("Transaction log in the service pingService recieved request as : {}",request);
		List<String> missingParameters = validateJsonRequest(request);
		if(!missingParameters.isEmpty()) {
			throw new DemoException("Following mandatory fields are missing in request Json: "+missingParameters);
		}
		ProducerRecord<String, String> record = new ProducerRecord<>(requestTopic, request);
		logger.info("Transaction log create producer record at : {} ", requestTopic);
		record.headers().add(new RecordHeader(KafkaHeaders.REPLY_TOPIC, requestReplyTopic.getBytes()));
		RequestReplyFuture<String, String, String> sendAndReceive = kafkaTemplate.sendAndReceive(record);
		ConsumerRecord<String, String> consumerRecord;
		String objectresponse = null;
		try {
			consumerRecord = sendAndReceive.get();
			objectresponse = consumerRecord.value();
			logger.info("Transaction log fetching consumer response as : {} ", consumerRecord.value());
		} catch (InterruptedException | ExecutionException e) {
			logger.error("Application log Exception occured consumer response reading : {} ", e.getCause());
			Thread.currentThread().interrupt();
		}
		lastAPIResp = objectresponse;
		return objectresponse;
	}
	
	@ResponseBody
	@PostMapping(value = "/acs", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String acsService(@RequestBody final String request){
		logger.info("Transaction log in the service acsService recieved request as : {}",request);
		String response = "{\"CarService\": [{\"vin\": \"BAUFOD4H361PMBB08\",\"modelCoding\": \"4MB0E1\",\"modelYear\": 2016,\"deliveryDate\": \"2015-08-12\",\"productionDate\": \"2015-07-19\",\"modelRange\": \"q7\",\"country\": \"DE\",\"language\": \"de\",\"shortName\": \"Audi Q7\",\"longName\": \"Audi Q7 3.0 TDI quattro 200(272) kW(PS) tiptronic 8-stufig\",\"incomplete\": [\"MODELRANGE\",\"WLTP\"]},{\"vin\": \"BAUVX2GEZ18041705\",\"modelCoding\": \"4N803A\",\"modelYear\": 2018,\"deliveryDate\": \"2016-09-23\",\"productionDate\": \"2016-09-23\",\"modelRange\": \"a8\",\"country\": \"DE\",\"language\": \"de\",\"shortName\": \"Audi A8 L\",\"longName\": \"Audi A8 L 50 TDI quattro\\t210(286)\\tkW(PS)\\ttiptronic\"},{\"vin\": \"BAUFOD4H361PMBB14\",\"modelCoding\": \"4MB0E1\",\"modelYear\": 2016,\"deliveryDate\": \"2015-08-12\",\"productionDate\": \"2015-07-19\",\"modelRange\": \"q7\",\"country\": \"DE\",\"language\": \"de\",\"shortName\": \"Audi Q7\",\"longName\": \"Audi Q7 3.0 TDI quattro 200(272) kW(PS) tiptronic 8-stufig\"},{\"vin\": \"BAUVX2GEZ18041702\",\"modelCoding\": \"4N803A\",\"modelYear\": 2018,\"deliveryDate\": \"2016-09-23\",\"productionDate\": \"2016-09-23\",\"modelRange\": \"a8\",\"country\": \"DE\",\"language\": \"de\",\"shortName\": \"Audi A8 L\",\"longName\": \"Audi A8 L 50 TDI quattro 210(286) kW(PS) tiptronic\"}],\"MAPS\": {\"kvpsid\": \"28100\",\"tenant\": \"DEU\"},\"GDPR\": {\"person\": {\"firstName\": \"Roland\",\"middleNames\": [],\"lastName\": \"Glaser\",\"accessList\": [\"de_10298206035422733073\",\"de_15438289844979051342\"]},\"businessTransaction\": [],\"customer\": {\"id\": \"de_16597761105421337199\",\"beneficiary\": \"de_10298206035422733073\",\"status\": \"ACTIVE\",\"preferredLanguage\": \"de\",\"person\": {\"firstName\": \"Roland\",\"middleNames\": [],\"lastName\": \"Glaser\",\"accessList\": [\"de_10298206035422733073\",\"de_15438289844979051342\"]},\"addresses\": [],\"emails\": [{\"clusterId\": \"7543270b-316c-4e60-9851-1399ca7bf26d\",\"gdpr\": {\"purpose\": \"de_17724593161236774745\",\"processingBasis\": \"BUSINESS_TRANSACTION\",\"channels\": []},\"accessList\": [\"de_10298206035422733073\",\"de_15438289844979051342\"],\"type\": \"PRIVATE\",\"address\": \"tgs_test@v11.co\",\"verified\": true}],\"phones\": [],\"integrationInfos\": [{\"systemId\": \"7368968643943927083\",\"integrationId\": \"W320455755\",\"statusInSystem\": \"ACTIVE\",\"lastUpdateInSystem\": \"2019-05-16T11:51:55.268Z\"}],\"orgaUnitRelations\": [],\"vehicleRelations\": [],\"brandShortnames\": [],\"meta\": {\"creationDate\": \"2019-05-16T15:59:17.365Z\",\"creationUser\": \"db-service-utils\"},\"accessList\": [\"de_10298206035422733073\",\"de_15438289844979051342\"],\"additionalInformation\": {\"gdprMatchId\": \"6d3be5e86b6f469ca7fb8904b0d48e7a\"}}}}";
		logger.info("Transaction log recieved response as : {}",response);
		return response;
	}

	@ResponseBody
	@PostMapping(value = "/milmarketconsumer", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String marketConsumerService(@RequestBody final String request) {
		logger.info("Transaction log in the service marketConsumerService recieved request as : {}", request);
		JSONObject jsonObject = new JSONObject(request);
		String acknowledgement = "Message acknowledged from market service";
		jsonObject.put("acknowledgement from market service", acknowledgement);
		logger.info("Transaction log market service acknowledgement msg : {}",jsonObject.toString());
		return jsonObject.toString();
	}
	
	private List<String> validateJsonRequest(String request){
		List<String> missedParameters = new ArrayList<>();
		JSONObject jsonObject = new JSONObject(request);
		if(jsonObject.isNull("ping")) {
			missedParameters.add("ping");
		}
		if(jsonObject.isNull("AUDIID")) {
			missedParameters.add("AUDIID");
		}
		if(jsonObject.isNull(JSON_OBJECT)) {
			missedParameters.add(JSON_OBJECT);
			return missedParameters;
		}else {
			JSONArray jsonArray = jsonObject.getJSONArray(JSON_OBJECT);
			for(int i=0;i< jsonArray.length();i++) {
				JSONObject jsonObj = jsonArray.getJSONObject(i);
				if(jsonObj.isNull("country")) {
					missedParameters.add("country");
					break;
				}
			}
		}
		
		return missedParameters;
	}

	@GetMapping("/latestPing")
	public String fetchLastAPIResponse() {
	    return lastAPIResp;
	  }
}
