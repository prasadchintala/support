package com.audi.mil.config;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import com.audi.mil.config.KafkaConfig;

@RunWith(MockitoJUnitRunner.class)
public class TestKafkaConfig {
	
private KafkaConfig kafkaConfig;
	
@Before
public void SetUp() throws Exception{
	kafkaConfig = new KafkaConfig();
}

@Test
public void TestProducerConfig() {
	assertNotNull(kafkaConfig.producerConfigs());
	assertNotNull(kafkaConfig.producerFactory());
	assertNotNull(kafkaConfig.consumerConfigs());
	assertNotNull(kafkaConfig.consumerFactory());
	assertNotNull(kafkaConfig.kafkaTemplate());
	kafkaConfig.replyContainer(kafkaConfig.consumerFactory());
	
}

//@Test
//public void TestConsumerConfig() {
//	Map<String, Object> props = kafkaConfig.consumerConfigs();
//	assertNotNull(props);
//	
//}
	

}
