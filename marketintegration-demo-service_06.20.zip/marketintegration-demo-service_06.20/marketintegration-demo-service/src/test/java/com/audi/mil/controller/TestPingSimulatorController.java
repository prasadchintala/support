package com.audi.mil.controller;

import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@RunWith(MockitoJUnitRunner.class)
public class TestPingSimulatorController {
	
	private PingSimulatorController pingSimulatorController;

	@Mock
	RestTemplate restTemplate;

	String request = null;
	String response = null;

	@Before
	public void simulatorsetup() {
		pingSimulatorController = new PingSimulatorController();
		request = "{\"ping\":89}";
		response = "{\"OK\"}";
		pingSimulatorController.pingReceiverUrl = "/MIL/milibeventreceiver";

	}

	@Test
	public void testPingSimulatorService() {
		restTemplate = Mockito.mock(RestTemplate.class);
		pingSimulatorController.restTemplate = restTemplate;
		
		   ResponseEntity<String> myEntity = new ResponseEntity<String>("SUCCESS",HttpStatus.OK);
	        Mockito.when(restTemplate.exchange(
	            Matchers.anyString(),
	            Matchers.any(HttpMethod.class),
	            Matchers.<HttpEntity<?>> any(),
	            Matchers.<Class<String>> any())
	        ).thenReturn(myEntity);

		HttpStatus response = pingSimulatorController.pingSimulatorService(request);
		assertNotNull(response);

	}
} 


