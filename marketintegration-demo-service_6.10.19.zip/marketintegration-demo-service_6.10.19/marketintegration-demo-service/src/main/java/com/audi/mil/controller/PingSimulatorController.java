package com.audi.mil.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.audi.mil.exception.DemoException;

@RestController
@RequestMapping(value = "MIL")
public class PingSimulatorController {

	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${ping.receiver.url}")
	String pingReceiverUrl;

	
	private static final Logger logger = LogManager.getLogger(PingSimulatorController.class);

	@ResponseBody
	@PostMapping(value = "/pingsimulator", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public HttpStatus pingSimulatorService(@RequestBody final String request) {
		logger.info("Transaction log recieved request as : {}", request);
		JSONObject jsonObject = new JSONObject(request);
		if (jsonObject.isNull("ping")) {
			throw new DemoException("ping is empty");
		}
		int ping = jsonObject.getInt("ping");
		String pingReceiverRequest = setPingReceiverRequest(ping);
		ResponseEntity<String> responseEntity = invokePingReciver(pingReceiverRequest);
		if(responseEntity!=null) {
			return responseEntity.getStatusCode();
			
		}
		return null;
	}

	private ResponseEntity<String> invokePingReciver(String pingReceiverRequest) {
		HttpHeaders headers  = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> requestEntity = new HttpEntity<>(pingReceiverRequest, headers);
		 return restTemplate.exchange(pingReceiverUrl,HttpMethod.POST, requestEntity, String.class);
		
	}

	private String setPingReceiverRequest(int ping) {
		if (ping == 84) {
			return "{\"ping\":84,\"eventDescription\":\"Customer_Created\",\"json_object\":[{\"country\":\"US\",\"integrationInfos\":[{\"systemId\":\"7368968643943927083\",\"statusInSystem\":\"ACTIVE\",\"integrationId\":\"e.g.webssoid\",\"lastUpdateInSystem\":\"2018-10-01T00:00:00Z\"}],\"legalEntities\":[\"de_2671997547190545746\",\"de_15438289844979051342\"],\"businessTransaction\":{\"identifier\":\"testdrive\",\"purpose\":[\"placeholder\"],\"id\":\"1901332423\",\"transactionId\":\"1901332423\"},\"user\":{\"sub\":\"mmustac@tria.hr\",\"legalEntityId\":\"de_2671997547190545746\",\"iss\":\"int.retailservices.audi.de\"}}],\"AUDIID\":\"de_523438956806307729\"}";
		} else if (ping == 88) {
			return "";
		} else if (ping == 89) {
			return "";
		} else if (ping == 90) {
			return "";
		} else {
			throw new DemoException("Ping Not found");
		}

	}

}
