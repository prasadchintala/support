package com.audi.mil.exception;

public class DemoException extends RuntimeException{

	public DemoException(String message) {
		super(message);
	}
	
}
