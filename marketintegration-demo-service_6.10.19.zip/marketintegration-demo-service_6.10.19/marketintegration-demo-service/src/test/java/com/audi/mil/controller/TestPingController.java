package com.audi.mil.controller;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URISyntaxException;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.MockConsumer;
import org.apache.kafka.clients.consumer.OffsetResetStrategy;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.kafka.requestreply.RequestReplyFuture;

import com.audi.mil.exception.DemoException;

@RunWith(MockitoJUnitRunner.class)
public class TestPingController{
 
  private PingController pingController;
  
  MockConsumer<String, String> consumer;
  
  @Mock
  ReplyingKafkaTemplate<String, String, String> kafkaTemplate;
  
  String request = null;
  String response = null;
  
  @Before
  public void setUp() {
	  pingController = new PingController();
	  request ="{\"ping\":6,\"AUDIID\":\"W123003931\",\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\",\"country\": \"CA\"}]}";
	  response ="{\"acknowledgement\": \"Message acknowledged for PingType:6\",\"ping\":6,\"AUDIID\":\"W123003931\",\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\",\"country\": \"CA\"}]}";
	  pingController.requestTopic = "testTopic";
	  pingController.requestReplyTopic = "testReplyTopic";
	  consumer = new MockConsumer<String, String>(OffsetResetStrategy.EARLIEST);
	  pingController.kafkaTemplate = kafkaTemplate;
	  pingController.lastAPIResp = response;
	 
	  
  }

  @Test
  public void testPingService() {
	  RequestReplyFuture<String, String, String> sendAndReceive = new RequestReplyFuture<String, String, String>();
	  ConsumerRecord<String, String> consumerRecord = new ConsumerRecord<String, String>(pingController.requestTopic, 0, 0L,null, response);
	  sendAndReceive.set(consumerRecord);
	  when(kafkaTemplate.sendAndReceive(Matchers.any())).thenReturn(sendAndReceive);
	  String response = pingController.pingService(request);
	  assertNotNull(response);
	  
  }
  
  @Test(expected = DemoException.class)
  public void testPingServiceNullPingNullAUDIIDNullCountry() {
	  String request ="{\"json_object\":[{\"eventDescription\": \"myAudi_user_deleted\",\"caller\": \"WEGA45599956\",\"key\": \"W983003931\"}]}";
	  pingController.pingService(request);
  }
  
  @Test(expected = DemoException.class)
  public void testPingServiceNullJsonObject() {
	  String request ="{\"ping\":6,\"AUDIID\":\"W123003931\"}";
	  pingController.pingService(request);
  }
  
  @Test
  public void testAcsService() throws IOException, URISyntaxException {
	  pingController.acsService("test");
  }
  
  @Test
  public void testLatestPingResponse() {
	  String latestResponse = pingController.fetchLastAPIResponse();
	  assertNotNull(latestResponse);
	  
  }
} 
